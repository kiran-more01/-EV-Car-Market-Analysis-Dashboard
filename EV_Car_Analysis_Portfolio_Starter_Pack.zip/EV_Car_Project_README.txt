EV CAR DATA ANALYSIS PORTFOLIO PROJECT
Tools: PostgreSQL / pgAdmin 4 + Power BI Desktop
Files:
- ev_car_analysis_dataset.csv: 1,200 synthetic sample records
- ev_car_project_sql.sql: table definition and analysis queries

IMPORTANT DATA NOTE:
This is a synthetic practice dataset designed for a portfolio project. Sales volumes and revenue are illustrative estimates, not verified real-world sales. Label them as estimated/sample values in your report. For a public-data version later, replace or supplement it with a sourced EV dataset and cite the source.

Suggested portfolio title:
EV Market Intelligence Dashboard | PostgreSQL + Power BI

Suggested dashboard pages:
1. Executive Overview: record count, brands, average price, average range, estimated units, estimated revenue.
2. Product & Technology: range by model, battery vs range scatter, charging time, body type mix.
3. Brand & Geography: estimated revenue by brand, records by country, filters for year/brand/body type.

Suggested Power BI measures (table name ev_cars):
Total Vehicle Records = COUNTROWS(ev_cars)
Brand Count = DISTINCTCOUNT(ev_cars[brand])
Average Price = AVERAGE(ev_cars[price_usd])
Average Range = AVERAGE(ev_cars[range_km])
Average Battery = AVERAGE(ev_cars[battery_capacity_kwh])
Estimated Units = SUM(ev_cars[units_sold_est])
Estimated Revenue = SUM(ev_cars[estimated_revenue_usd])
Average Charging Time = AVERAGE(ev_cars[charging_time_hr])
Range per kWh Proxy = DIVIDE(AVERAGE(ev_cars[range_km]), AVERAGE(ev_cars[battery_capacity_kwh]))

Recommended slicers: model_year, brand, country, body_type.
Recommended visuals: KPI cards, bar chart, line chart, scatter plot, donut chart, matrix/table.
